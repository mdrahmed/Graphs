Similar patterns from Delivery phase,
From 1st, 2nd, and 34d WORKPIECE DELIVERED
Following 3 are similar,
```
combined-graph-31.dot
combined-graph-70.dot
combined-graph-132.dot
```
These have similar patterns,
```
combined-graph-33.dot
combined-graph-34.dot
combined-graph-74.dot
combined-graph-75.dot
combined-graph-135.dot
combined-graph-136.dot
```
These have similar patterns,
```
combined-graph-36.dot
combined-graph-78.dot
```
These have similar patterns,
```
combined-graph-40.dot
combined-graph-80.dot
```
These have similar patterns,
```
combined-graph-81.dot
combined-graph-139.dot
combined-graph-142.dot
```
