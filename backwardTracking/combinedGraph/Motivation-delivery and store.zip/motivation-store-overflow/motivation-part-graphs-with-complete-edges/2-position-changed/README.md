I have stored 7 workpieces and changed 2 position,

    6th position (1,2) from 1 to 0.
    9th position (2,2) from 0 to 1.

Now, the graph is shown.
