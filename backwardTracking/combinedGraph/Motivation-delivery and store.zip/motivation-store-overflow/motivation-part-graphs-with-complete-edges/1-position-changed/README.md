I have stored 7 workpieces and changed 1 position (1,2) - the 6th positon from 1 to 0. And the graph of that is shown here.
