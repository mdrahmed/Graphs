#### Attack 1. Delivery-underflow
It contains the stateful graphs.
