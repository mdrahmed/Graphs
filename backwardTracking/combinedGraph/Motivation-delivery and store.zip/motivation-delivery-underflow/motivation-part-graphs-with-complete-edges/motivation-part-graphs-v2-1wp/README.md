This folder contains a complete stateful graph after storing 1 workpiece a 0,0 and then ordering 1 workpiece from 0,1 to show the attack

Input: `hbw/ack`, dataset: `motivation-log-v2-delivery`

