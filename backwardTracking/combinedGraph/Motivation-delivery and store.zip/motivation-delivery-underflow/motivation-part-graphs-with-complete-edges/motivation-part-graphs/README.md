This folder has graph same as motivation-part-graphs-v2-1wp but it is starting from the `storeContainer`, which is storing the empty container back to the storage.

Input: `storeContainer`, dataset: `motivation-log-v2-delivery`
