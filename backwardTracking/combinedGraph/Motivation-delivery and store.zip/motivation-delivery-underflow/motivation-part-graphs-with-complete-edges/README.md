#### Attack 1. Delivery-underflow
##### With complete hbw & vgr edges
```
motivation-part-graphs-with-complete-edges/motivation-delivery-underflow/motivation-part-graphs-v2-1wp 
# input: hbw/ack, dataset: motivation-log-v2-delivery
# This folder contains a complete stateful graph after storing 1 workpiece a 0,0 and then ordering 1 workpiece from 0,1 to show the attack 
motivation-part-graphs-with-complete-edges/motivation-delivery-underflow/motivation-part-graphs-v3-9wp 
# this folder contains a complete stateful graph after storing 9 workpieces in the HBW and then ordering 1 wp from 0,1 and again ordering from 0,1 to show the attack
#input: topic, dataset: motivation-log-v3
motivation-part-graphs-with-complete-edges/motivation-delivery-underflow/motivation-part-graphs 
# This folder has graph same as motivation-part-graphs-v2-1wp but it is starting from the storeContainer, which is storing the empty container back to the storage.
# input: storeContainer, dataset: motivation-log-v2-delivery
```
