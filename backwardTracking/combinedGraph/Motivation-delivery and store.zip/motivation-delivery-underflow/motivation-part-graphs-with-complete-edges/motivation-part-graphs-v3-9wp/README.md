This folder contains a complete stateful graph after storing 9 workpieces in the HBW and then ordering 1 wp from 0,1 and again ordering from 0,1 to show the attack.

Input: `topic`, dataset: `motivation-log-v3`
