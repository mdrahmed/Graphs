#### Attack 1. Delivery-underflow
##### Without complete vgr edges
```
motivation-part-graphs-without-complete-edges/motivation-delivery-underflow/motivation-part-graphs-v2-1wp
# This folder contains a complete stateful graph after storing 1 workpiece a 0,0 and then ordering 1 workpiece from 0,1 to show the attack
# input: hbw/ack
motivation-part-graphs-without-complete-edges/motivation-delivery-underflow/motivation-part-graphs-v3-9wp
# this folder contains a complete stateful graph after storing 9 workpieces in the HBW and then ordering 1 wp from 0,1 and again ordering from 0,1 to show the attack
#input: topic
motivation-part-graphs-without-complete-edges/motivation-delivery-underflow/motivation-part-graphs
# This folder has graph same as motivation-part-graphs-v2-1wp but it is starting from the storeContainer, which is storing the empty container back to the storage.
# input: storeContainer
```
